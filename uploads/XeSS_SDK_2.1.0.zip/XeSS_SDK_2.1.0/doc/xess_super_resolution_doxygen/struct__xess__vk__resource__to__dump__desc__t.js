var struct__xess__vk__resource__to__dump__desc__t =
[
    [ "buffer", "struct__xess__vk__resource__to__dump__desc__t.html#afb1211892a082f365aec675b78078cc5", null ],
    [ "height", "struct__xess__vk__resource__to__dump__desc__t.html#a6ad4f820ce4e75cda0686fcaad5168be", null ],
    [ "image", "struct__xess__vk__resource__to__dump__desc__t.html#ac48af4a2f518b64b67c40aa0efa7de6b", null ],
    [ "image_array_size", "struct__xess__vk__resource__to__dump__desc__t.html#a907e3e2edd5c6000a53a2d1838b052a7", null ],
    [ "image_depth", "struct__xess__vk__resource__to__dump__desc__t.html#a886ea72f5466e4e284c78da6857e689a", null ],
    [ "image_format", "struct__xess__vk__resource__to__dump__desc__t.html#a3283d6fcd9b93efe2ee98a50a36c2d7d", null ],
    [ "image_layout", "struct__xess__vk__resource__to__dump__desc__t.html#a31222575e87bcd00b6bf9046e8a98cbb", null ],
    [ "width", "struct__xess__vk__resource__to__dump__desc__t.html#aa03703b9c1bfb2a966195b99451168e5", null ]
];