var searchData=
[
  ['major_0',['major',['../struct__xefg__swapchain__version__t.html#a600930655b7237315b72223c48327ea8',1,'_xefg_swapchain_version_t']]],
  ['maxinterpolatedframes_1',['maxInterpolatedFrames',['../struct__xefg__swapchain__d3d12__init__params__t.html#ad7b639312c832f450ca18f6995f7f883',1,'_xefg_swapchain_d3d12_init_params_t']]],
  ['maxsupportedinterpolations_2',['maxSupportedInterpolations',['../struct__xefg__swapchain__properties__t.html#a1fa2dc656ac92d91f36b933a9632ac85',1,'_xefg_swapchain_properties_t']]],
  ['minor_3',['minor',['../struct__xefg__swapchain__version__t.html#a9f280ce3ae5b6cd9346fd7a09ff29168',1,'_xefg_swapchain_version_t']]],
  ['motionvectorscalex_4',['motionVectorScaleX',['../struct__xefg__swapchain__frame__constant__data__t.html#a9f7ba84c487c97cb308b83a0017846f4',1,'_xefg_swapchain_frame_constant_data_t']]],
  ['motionvectorscaley_5',['motionVectorScaleY',['../struct__xefg__swapchain__frame__constant__data__t.html#afab3c0ba1c54e7874ed4a27ceaf2caad',1,'_xefg_swapchain_frame_constant_data_t']]]
];
