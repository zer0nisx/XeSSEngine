var searchData=
[
  ['_5fxefg_5fswapchain_5f2d_5ft_0',['_xefg_swapchain_2d_t',['../struct__xefg__swapchain__2d__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fd3d12_5finit_5fparams_5ft_1',['_xefg_swapchain_d3d12_init_params_t',['../struct__xefg__swapchain__d3d12__init__params__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fd3d12_5fresource_5fdata_5ft_2',['_xefg_swapchain_d3d12_resource_data_t',['../struct__xefg__swapchain__d3d12__resource__data__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fdebug_5ffeature_5ft_3',['_xefg_swapchain_debug_feature_t',['../xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187e',1,'xefg_swapchain_debug.h']]],
  ['_5fxefg_5fswapchain_5fframe_5fconstant_5fdata_5ft_4',['_xefg_swapchain_frame_constant_data_t',['../struct__xefg__swapchain__frame__constant__data__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5finit_5fflags_5ft_5',['_xefg_swapchain_init_flags_t',['../xefg__swapchain_8h.html#a7a1b52e2867d7b1caefc194774ddb5dc',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5flogging_5flevel_5ft_6',['_xefg_swapchain_logging_level_t',['../xefg__swapchain_8h.html#a950e564faf207cfec778269ae3200b3f',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fpresent_5fstatus_5ft_7',['_xefg_swapchain_present_status_t',['../struct__xefg__swapchain__present__status__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fproperties_5ft_8',['_xefg_swapchain_properties_t',['../struct__xefg__swapchain__properties__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fresource_5ftype_5ft_9',['_xefg_swapchain_resource_type_t',['../xefg__swapchain_8h.html#a82da6e339d59c06860998efba6689656',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fresource_5fvalidity_5ft_10',['_xefg_swapchain_resource_validity_t',['../xefg__swapchain_8h.html#a382af9be9870bf20dc587ec9a2f2c479',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fresult_5ft_11',['_xefg_swapchain_result_t',['../xefg__swapchain_8h.html#afd4162fa9f2d864f1a9126eea6245fa0',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fui_5fmode_5ft_12',['_xefg_swapchain_ui_mode_t',['../xefg__swapchain_8h.html#a61355ff6fd805c383cd8ff99cc132b58',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fversion_5ft_13',['_xefg_swapchain_version_t',['../struct__xefg__swapchain__version__t.html',1,'']]]
];
