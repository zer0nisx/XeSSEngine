var searchData=
[
  ['validity_0',['validity',['../struct__xefg__swapchain__d3d12__resource__data__t.html#a0065b26c8e441f05c5b0083df8fa74aa',1,'_xefg_swapchain_d3d12_resource_data_t']]],
  ['viewmatrix_1',['viewMatrix',['../struct__xefg__swapchain__frame__constant__data__t.html#a370ca156b42f948ef96786d1dd21365e',1,'_xefg_swapchain_frame_constant_data_t']]],
  ['visiblenodemask_2',['visibleNodeMask',['../struct__xefg__swapchain__d3d12__init__params__t.html#a153b79c833ddce15c33d78691a679ca3',1,'_xefg_swapchain_d3d12_init_params_t']]]
];
