var struct__xefg__swapchain__frame__constant__data__t =
[
    [ "frameRenderTime", "struct__xefg__swapchain__frame__constant__data__t.html#a177cfa7f26fd6469195fb08f59579218", null ],
    [ "jitterOffsetX", "struct__xefg__swapchain__frame__constant__data__t.html#a701953ac726be26afde35ba21b1854f5", null ],
    [ "jitterOffsetY", "struct__xefg__swapchain__frame__constant__data__t.html#ab8fec73568168bc8ba655190c20b98b0", null ],
    [ "motionVectorScaleX", "struct__xefg__swapchain__frame__constant__data__t.html#a9f7ba84c487c97cb308b83a0017846f4", null ],
    [ "motionVectorScaleY", "struct__xefg__swapchain__frame__constant__data__t.html#afab3c0ba1c54e7874ed4a27ceaf2caad", null ],
    [ "projectionMatrix", "struct__xefg__swapchain__frame__constant__data__t.html#ac9131354de4b011211d3a2a2c796053d", null ],
    [ "resetHistory", "struct__xefg__swapchain__frame__constant__data__t.html#af2336172df07c9d4a8d36a9a1f188a2e", null ],
    [ "viewMatrix", "struct__xefg__swapchain__frame__constant__data__t.html#a370ca156b42f948ef96786d1dd21365e", null ]
];