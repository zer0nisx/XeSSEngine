var searchData=
[
  ['bufferheapoffset_0',['bufferHeapOffset',['../struct__xefg__swapchain__d3d12__init__params__t.html#aca551e5731fdfe7679b6f3e24cc01d0c',1,'_xefg_swapchain_d3d12_init_params_t']]]
];
