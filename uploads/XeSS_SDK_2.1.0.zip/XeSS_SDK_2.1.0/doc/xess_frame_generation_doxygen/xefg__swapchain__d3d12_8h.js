var xefg__swapchain__d3d12_8h =
[
    [ "_xefg_swapchain_d3d12_init_params_t", "struct__xefg__swapchain__d3d12__init__params__t.html", "struct__xefg__swapchain__d3d12__init__params__t" ],
    [ "_xefg_swapchain_d3d12_resource_data_t", "struct__xefg__swapchain__d3d12__resource__data__t.html", "struct__xefg__swapchain__d3d12__resource__data__t" ],
    [ "xefg_swapchain_d3d12_init_params_t", "xefg__swapchain__d3d12_8h.html#a13b6293847a4ac0f8d07474231cd4599", null ],
    [ "xefg_swapchain_d3d12_resource_data_t", "xefg__swapchain__d3d12_8h.html#af4bf1bb6fd4396dd3fa97858809facef", null ],
    [ "xefgSwapChainD3D12BuildPipelines", "group__xefgswapchain-d3d12.html#ga65ae23e57239395a0004c76bbe856bc1", null ],
    [ "xefgSwapChainD3D12CreateContext", "group__xefgswapchain-d3d12.html#gad79053e072e6d5d9c209f30b913c3f3e", null ],
    [ "xefgSwapChainD3D12GetSwapChainPtr", "group__xefgswapchain-d3d12.html#gac34454b51b4f41d8b12630e7b229d71c", null ],
    [ "xefgSwapChainD3D12InitFromSwapChain", "group__xefgswapchain-d3d12.html#gaba813bce521f4c803e3d04cd0be9810d", null ],
    [ "xefgSwapChainD3D12InitFromSwapChainDesc", "group__xefgswapchain-d3d12.html#gaf7ea0fd5979500a8c96972cb5b7638b4", null ],
    [ "xefgSwapChainD3D12SetDescriptorHeap", "group__xefgswapchain-d3d12.html#ga5158492f6a64dcc51a2b7728bb9d562a", null ],
    [ "xefgSwapChainD3D12TagFrameResource", "group__xefgswapchain-d3d12.html#gaded3dad4aaa43cec681b3bce376d3d29", null ]
];