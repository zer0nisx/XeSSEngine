var searchData=
[
  ['requireddescriptorcount_0',['requiredDescriptorCount',['../struct__xefg__swapchain__properties__t.html#a2dc96375a6205c03219a9904a568c01c',1,'_xefg_swapchain_properties_t']]],
  ['reserved_1',['reserved',['../struct__xefg__swapchain__version__t.html#a5a6ed8c04a3db86066924b1a1bf4dad3',1,'_xefg_swapchain_version_t']]],
  ['resethistory_2',['resetHistory',['../struct__xefg__swapchain__frame__constant__data__t.html#af2336172df07c9d4a8d36a9a1f188a2e',1,'_xefg_swapchain_frame_constant_data_t']]],
  ['resourcebase_3',['resourceBase',['../struct__xefg__swapchain__d3d12__resource__data__t.html#a8c597821be2797f9271542f839110d5d',1,'_xefg_swapchain_d3d12_resource_data_t']]],
  ['resourcesize_4',['resourceSize',['../struct__xefg__swapchain__d3d12__resource__data__t.html#a4aedb8d2d8766d045adc1d4851c20598',1,'_xefg_swapchain_d3d12_resource_data_t']]]
];
