var searchData=
[
  ['_5fxefg_5fswapchain_5fdebug_5ffeature_5ft_0',['_xefg_swapchain_debug_feature_t',['../xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187e',1,'xefg_swapchain_debug.h']]],
  ['_5fxefg_5fswapchain_5finit_5fflags_5ft_1',['_xefg_swapchain_init_flags_t',['../xefg__swapchain_8h.html#a7a1b52e2867d7b1caefc194774ddb5dc',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5flogging_5flevel_5ft_2',['_xefg_swapchain_logging_level_t',['../xefg__swapchain_8h.html#a950e564faf207cfec778269ae3200b3f',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fresource_5ftype_5ft_3',['_xefg_swapchain_resource_type_t',['../xefg__swapchain_8h.html#a82da6e339d59c06860998efba6689656',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fresource_5fvalidity_5ft_4',['_xefg_swapchain_resource_validity_t',['../xefg__swapchain_8h.html#a382af9be9870bf20dc587ec9a2f2c479',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fresult_5ft_5',['_xefg_swapchain_result_t',['../xefg__swapchain_8h.html#afd4162fa9f2d864f1a9126eea6245fa0',1,'xefg_swapchain.h']]],
  ['_5fxefg_5fswapchain_5fui_5fmode_5ft_6',['_xefg_swapchain_ui_mode_t',['../xefg__swapchain_8h.html#a61355ff6fd805c383cd8ff99cc132b58',1,'xefg_swapchain.h']]]
];
