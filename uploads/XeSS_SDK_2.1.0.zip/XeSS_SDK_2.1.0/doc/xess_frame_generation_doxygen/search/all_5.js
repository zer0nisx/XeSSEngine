var searchData=
[
  ['jitteroffsetx_0',['jitterOffsetX',['../struct__xefg__swapchain__frame__constant__data__t.html#a701953ac726be26afde35ba21b1854f5',1,'_xefg_swapchain_frame_constant_data_t']]],
  ['jitteroffsety_1',['jitterOffsetY',['../struct__xefg__swapchain__frame__constant__data__t.html#ab8fec73568168bc8ba655190c20b98b0',1,'_xefg_swapchain_frame_constant_data_t']]]
];
