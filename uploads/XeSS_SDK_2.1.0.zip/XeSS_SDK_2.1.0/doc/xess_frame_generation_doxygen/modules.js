var modules =
[
    [ "XeSS-FG Swap Chain API exports", "group__xefgswapchain.html", "group__xefgswapchain" ],
    [ "XeSS-FG Swap Chain D3D12 API exports", "group__xefgswapchain-d3d12.html", "group__xefgswapchain-d3d12" ],
    [ "XeSS-FG Swap Chain debug features", "group__xefgswapchain__debug.html", "group__xefgswapchain__debug" ]
];