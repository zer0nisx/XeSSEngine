var struct__xess__profiling__data__t =
[
    [ "any_profiling_data_in_flight", "struct__xess__profiling__data__t.html#a7ce6d3494f6a8695edf94fcad38c455e", null ],
    [ "frame_count", "struct__xess__profiling__data__t.html#a75021619d6a71e1e1a4ea1efb3c62138", null ],
    [ "frames", "struct__xess__profiling__data__t.html#a34fa47cf13f15a0c84ae5bc36f08fc1e", null ]
];