var indexSectionsWithContent =
{
  0: "_abcdefghijmopqrstvwxy",
  1: "_",
  2: "x",
  3: "x",
  4: "abcdefghijmopqrstvwxy",
  5: "sx",
  6: "_",
  7: "x",
  8: "x",
  9: "x"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules"
};

