var struct__xefg__swapchain__version__t =
[
    [ "major", "struct__xefg__swapchain__version__t.html#a600930655b7237315b72223c48327ea8", null ],
    [ "minor", "struct__xefg__swapchain__version__t.html#a9f280ce3ae5b6cd9346fd7a09ff29168", null ],
    [ "patch", "struct__xefg__swapchain__version__t.html#ab74656704767a7e73da4cd20dfd51a5d", null ],
    [ "reserved", "struct__xefg__swapchain__version__t.html#a5a6ed8c04a3db86066924b1a1bf4dad3", null ]
];