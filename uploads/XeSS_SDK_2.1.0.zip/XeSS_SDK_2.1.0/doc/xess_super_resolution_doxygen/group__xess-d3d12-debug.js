var group__xess_d3d12_debug =
[
    [ "xessD3D12GetProfilingData", "group__xess-d3d12-debug.html#ga3a8e8bee0b8ba06871c765648202c938", null ],
    [ "xessD3D12GetResourcesToDump", "group__xess-d3d12-debug.html#gaf62cb7b5e756de611a19896a5248c92b", null ]
];