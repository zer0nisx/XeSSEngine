var struct__xess__properties__t =
[
    [ "requiredDescriptorCount", "struct__xess__properties__t.html#a2dc96375a6205c03219a9904a568c01c", null ],
    [ "tempBufferHeapSize", "struct__xess__properties__t.html#a0db8617705e860098e048d7f3e5466ff", null ],
    [ "tempTextureHeapSize", "struct__xess__properties__t.html#a209e8c58699154a12ca8c51d190565ee", null ]
];