var searchData=
[
  ['papplicationswapchain_0',['pApplicationSwapChain',['../struct__xefg__swapchain__d3d12__init__params__t.html#abfbeecbf2227fe3e64d660e332f5b495',1,'_xefg_swapchain_d3d12_init_params_t']]],
  ['patch_1',['patch',['../struct__xefg__swapchain__version__t.html#ab74656704767a7e73da4cd20dfd51a5d',1,'_xefg_swapchain_version_t']]],
  ['ppipelinelibrary_2',['pPipelineLibrary',['../struct__xefg__swapchain__d3d12__init__params__t.html#a254d1c85f1dde5405a267084da481ad9',1,'_xefg_swapchain_d3d12_init_params_t']]],
  ['presource_3',['pResource',['../struct__xefg__swapchain__d3d12__resource__data__t.html#aefa2fb8fe78611dda8fe9a4f7e8fed78',1,'_xefg_swapchain_d3d12_resource_data_t']]],
  ['projectionmatrix_4',['projectionMatrix',['../struct__xefg__swapchain__frame__constant__data__t.html#ac9131354de4b011211d3a2a2c796053d',1,'_xefg_swapchain_frame_constant_data_t']]],
  ['ptempbufferheap_5',['pTempBufferHeap',['../struct__xefg__swapchain__d3d12__init__params__t.html#a8b41cbb0e0c875bf2631ef6b414d4259',1,'_xefg_swapchain_d3d12_init_params_t']]],
  ['ptemptextureheap_6',['pTempTextureHeap',['../struct__xefg__swapchain__d3d12__init__params__t.html#a32b6ed71e10b2df805c033b158f9d1f5',1,'_xefg_swapchain_d3d12_init_params_t']]]
];
