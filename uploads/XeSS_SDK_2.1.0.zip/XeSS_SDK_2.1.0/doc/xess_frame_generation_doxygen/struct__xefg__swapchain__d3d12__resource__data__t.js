var struct__xefg__swapchain__d3d12__resource__data__t =
[
    [ "incomingState", "struct__xefg__swapchain__d3d12__resource__data__t.html#af24abfcc57a728d25d91b7b75a13553d", null ],
    [ "pResource", "struct__xefg__swapchain__d3d12__resource__data__t.html#aefa2fb8fe78611dda8fe9a4f7e8fed78", null ],
    [ "resourceBase", "struct__xefg__swapchain__d3d12__resource__data__t.html#a8c597821be2797f9271542f839110d5d", null ],
    [ "resourceSize", "struct__xefg__swapchain__d3d12__resource__data__t.html#a4aedb8d2d8766d045adc1d4851c20598", null ],
    [ "type", "struct__xefg__swapchain__d3d12__resource__data__t.html#acb5d94c09d77cd739ad2a31cb9931443", null ],
    [ "validity", "struct__xefg__swapchain__d3d12__resource__data__t.html#a0065b26c8e441f05c5b0083df8fa74aa", null ]
];