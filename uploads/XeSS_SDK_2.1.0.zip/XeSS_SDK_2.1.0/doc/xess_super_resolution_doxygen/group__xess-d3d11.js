var group__xess_d3d11 =
[
    [ "xessD3D11CreateContext", "group__xess-d3d11.html#ga5a64ca022d096bbb6b814d4edd7877b5", null ],
    [ "xessD3D11Execute", "group__xess-d3d11.html#ga07442406f816bb0776c521a4b0085f96", null ],
    [ "xessD3D11GetInitParams", "group__xess-d3d11.html#ga7027403e2782e57c8b2c044c19a48a8e", null ],
    [ "xessD3D11Init", "group__xess-d3d11.html#ga707b311ffa7b8f199602854ffb568604", null ]
];