var struct__xefg__swapchain__d3d12__init__params__t =
[
    [ "bufferHeapOffset", "struct__xefg__swapchain__d3d12__init__params__t.html#aca551e5731fdfe7679b6f3e24cc01d0c", null ],
    [ "creationNodeMask", "struct__xefg__swapchain__d3d12__init__params__t.html#a5a826e34a732802a584fc78091837dc4", null ],
    [ "initFlags", "struct__xefg__swapchain__d3d12__init__params__t.html#a2778ccc4a0cacda6c2c73482a77f6e05", null ],
    [ "maxInterpolatedFrames", "struct__xefg__swapchain__d3d12__init__params__t.html#ad7b639312c832f450ca18f6995f7f883", null ],
    [ "pApplicationSwapChain", "struct__xefg__swapchain__d3d12__init__params__t.html#abfbeecbf2227fe3e64d660e332f5b495", null ],
    [ "pPipelineLibrary", "struct__xefg__swapchain__d3d12__init__params__t.html#a254d1c85f1dde5405a267084da481ad9", null ],
    [ "pTempBufferHeap", "struct__xefg__swapchain__d3d12__init__params__t.html#a8b41cbb0e0c875bf2631ef6b414d4259", null ],
    [ "pTempTextureHeap", "struct__xefg__swapchain__d3d12__init__params__t.html#a32b6ed71e10b2df805c033b158f9d1f5", null ],
    [ "textureHeapOffset", "struct__xefg__swapchain__d3d12__init__params__t.html#a9e2ba8ca5471d07e4bb30183deb00e56", null ],
    [ "uiMode", "struct__xefg__swapchain__d3d12__init__params__t.html#a6f629178545fb5358725222aebc35f14", null ],
    [ "visibleNodeMask", "struct__xefg__swapchain__d3d12__init__params__t.html#a153b79c833ddce15c33d78691a679ca3", null ]
];