var xess__vk__debug_8h =
[
    [ "_xess_vk_resource_to_dump_desc_t", "struct__xess__vk__resource__to__dump__desc__t.html", "struct__xess__vk__resource__to__dump__desc__t" ],
    [ "_xess_vk_resources_to_dump_t", "struct__xess__vk__resources__to__dump__t.html", "struct__xess__vk__resources__to__dump__t" ],
    [ "xess_vk_resource_to_dump_desc_t", "xess__vk__debug_8h.html#add779cd61fb420d970feaf062eefe350", null ],
    [ "xess_vk_resources_to_dump_t", "xess__vk__debug_8h.html#a0ffbb82578bd186707a0413b2b8067b3", null ],
    [ "xessVKGetResourcesToDump", "group__xess-vk-debug.html#gaa5464710fa5a818d07340f470b4d522c", null ]
];