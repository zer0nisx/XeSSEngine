var group__xess =
[
    [ "xessDestroyContext", "group__xess.html#gae5d88d9bdb50033ab254aa2e692c9bc0", null ],
    [ "xessForceLegacyScaleFactors", "group__xess.html#ga016818ad0a8454cfce7a2316450df20e", null ],
    [ "xessGetExposureMultiplier", "group__xess.html#ga84293d9d7a2331dcac496a3dbb8a9a7c", null ],
    [ "xessGetInputResolution", "group__xess.html#ga6ed6ab924e0a41ff56485b562acd5073", null ],
    [ "xessGetIntelXeFXVersion", "group__xess.html#ga88ea52641806d14ef5a4995b5d78ea91", null ],
    [ "xessGetJitterScale", "group__xess.html#gaaaff5dc2376dd08bd1f451e61fdc8784", null ],
    [ "xessGetMaxResponsiveMaskValue", "group__xess.html#ga646d20a888b6dd13793717dd1e3d800c", null ],
    [ "xessGetOptimalInputResolution", "group__xess.html#gadf70f7ff418f9aeb9bf3dbabf2fb50ed", null ],
    [ "xessGetPipelineBuildStatus", "group__xess.html#gaa148190453919ceae0cd3ffb22593389", null ],
    [ "xessGetProperties", "group__xess.html#gaae4893a4bfed059402ca55f256738773", null ],
    [ "xessGetVelocityScale", "group__xess.html#ga7c6c49e93cc5f102473c76cfa1081bd5", null ],
    [ "xessGetVersion", "group__xess.html#ga0fc6e0c7b21322a0af96f1ee1e4667d3", null ],
    [ "xessIsOptimalDriver", "group__xess.html#ga716ee0ab9df5de9726315ba5df21308c", null ],
    [ "xessSetExposureMultiplier", "group__xess.html#gae86133e9850ce4926f97e96a888259cc", null ],
    [ "xessSetJitterScale", "group__xess.html#ga30e9bee98f90568e6a9d39bd7d1ccd74", null ],
    [ "xessSetLoggingCallback", "group__xess.html#gaaf68a347af5e5c9c1e518f0bc5daaf1c", null ],
    [ "xessSetMaxResponsiveMaskValue", "group__xess.html#ga522339152e9175761232b05b5e13e5c6", null ],
    [ "xessSetVelocityScale", "group__xess.html#ga0f95b12fe2611b877d72efdd9f050639", null ]
];