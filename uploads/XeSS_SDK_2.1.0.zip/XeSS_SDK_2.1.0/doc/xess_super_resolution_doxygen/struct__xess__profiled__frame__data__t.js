var struct__xess__profiled__frame__data__t =
[
    [ "frame_index", "struct__xess__profiled__frame__data__t.html#a7b9f42d4c57d1fe01c782d735be98074", null ],
    [ "gpu_duration_names", "struct__xess__profiled__frame__data__t.html#a46e787a4e8a96da32fe2b173f3720d6f", null ],
    [ "gpu_duration_record_count", "struct__xess__profiled__frame__data__t.html#ab142b6f60de7c00c227011353cb602e5", null ],
    [ "gpu_duration_values", "struct__xess__profiled__frame__data__t.html#a8f6650843400b1532bdd0ce000a0e689", null ]
];