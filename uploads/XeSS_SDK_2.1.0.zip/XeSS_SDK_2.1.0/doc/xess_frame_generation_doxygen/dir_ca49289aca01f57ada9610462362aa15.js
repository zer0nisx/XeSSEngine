var dir_ca49289aca01f57ada9610462362aa15 =
[
    [ "xefg_swapchain.h", "xefg__swapchain_8h.html", "xefg__swapchain_8h" ],
    [ "xefg_swapchain_d3d12.h", "xefg__swapchain__d3d12_8h.html", "xefg__swapchain__d3d12_8h" ],
    [ "xefg_swapchain_debug.h", "xefg__swapchain__debug_8h.html", "xefg__swapchain__debug_8h" ]
];