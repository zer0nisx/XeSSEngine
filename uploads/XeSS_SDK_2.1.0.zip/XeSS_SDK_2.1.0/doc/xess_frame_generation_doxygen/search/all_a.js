var searchData=
[
  ['uimode_0',['uiMode',['../struct__xefg__swapchain__d3d12__init__params__t.html#a6f629178545fb5358725222aebc35f14',1,'_xefg_swapchain_d3d12_init_params_t']]]
];
