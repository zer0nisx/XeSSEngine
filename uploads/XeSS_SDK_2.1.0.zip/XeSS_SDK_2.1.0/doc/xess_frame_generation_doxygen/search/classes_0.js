var searchData=
[
  ['_5fxefg_5fswapchain_5f2d_5ft_0',['_xefg_swapchain_2d_t',['../struct__xefg__swapchain__2d__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fd3d12_5finit_5fparams_5ft_1',['_xefg_swapchain_d3d12_init_params_t',['../struct__xefg__swapchain__d3d12__init__params__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fd3d12_5fresource_5fdata_5ft_2',['_xefg_swapchain_d3d12_resource_data_t',['../struct__xefg__swapchain__d3d12__resource__data__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fframe_5fconstant_5fdata_5ft_3',['_xefg_swapchain_frame_constant_data_t',['../struct__xefg__swapchain__frame__constant__data__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fpresent_5fstatus_5ft_4',['_xefg_swapchain_present_status_t',['../struct__xefg__swapchain__present__status__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fproperties_5ft_5',['_xefg_swapchain_properties_t',['../struct__xefg__swapchain__properties__t.html',1,'']]],
  ['_5fxefg_5fswapchain_5fversion_5ft_6',['_xefg_swapchain_version_t',['../struct__xefg__swapchain__version__t.html',1,'']]]
];
