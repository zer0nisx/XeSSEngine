var xefg__swapchain__debug_8h =
[
    [ "xefg_swapchain_debug_feature_t", "xefg__swapchain__debug_8h.html#a84ece8e153d1c4f6151054d908817073", null ],
    [ "_xefg_swapchain_debug_feature_t", "xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187e", [
      [ "XEFG_SWAPCHAIN_DEBUG_FEATURE_SHOW_ONLY_INTERPOLATION", "xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187ea3771529f240dbd9458d0b3388f7ace9f", null ],
      [ "XEFG_SWAPCHAIN_DEBUG_FEATURE_TAG_INTERPOLATED_FRAMES", "xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187ea996a7bc8e5b02bd84438b08208ff5948", null ],
      [ "XEFG_SWAPCHAIN_DEBUG_FEATURE_PRESENT_FAILED_INTERPOLATION", "xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187ea0698031a20bf7bbfe1d9b4545cd85e56", null ],
      [ "XEFG_SWAPCHAIN_DEBUG_FEATURE_RES_COUNT", "xefg__swapchain__debug_8h.html#a478cd177e09b7c1b892efcff83d5187ea62bf5ac485c9894d2f22accaa622693b", null ]
    ] ],
    [ "XEFG_SWAPCHAIN_STATIC_ASSERT", "xefg__swapchain__debug_8h.html#ad35c8ca2f1fa12346f226f02649ab0f1", null ],
    [ "xefgSwapChainEnableDebugFeature", "group__xefgswapchain__debug.html#gaf2d5b3aa72a5615fd5ac700b5574c231", null ]
];