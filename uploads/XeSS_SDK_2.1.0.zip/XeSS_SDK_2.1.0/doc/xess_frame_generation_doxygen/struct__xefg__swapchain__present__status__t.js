var struct__xefg__swapchain__present__status__t =
[
    [ "frameGenResult", "struct__xefg__swapchain__present__status__t.html#a61d64decd8963c48a3bdc1d0e3051479", null ],
    [ "framesPresented", "struct__xefg__swapchain__present__status__t.html#a2fe0993bf79740d78bbbb3c9f093c2d0", null ],
    [ "isFrameGenEnabled", "struct__xefg__swapchain__present__status__t.html#a61ea2b8bf9271fe0500464d4b37f82fe", null ]
];