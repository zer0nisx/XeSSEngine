var annotated_dup =
[
    [ "_xefg_swapchain_2d_t", "struct__xefg__swapchain__2d__t.html", "struct__xefg__swapchain__2d__t" ],
    [ "_xefg_swapchain_d3d12_init_params_t", "struct__xefg__swapchain__d3d12__init__params__t.html", "struct__xefg__swapchain__d3d12__init__params__t" ],
    [ "_xefg_swapchain_d3d12_resource_data_t", "struct__xefg__swapchain__d3d12__resource__data__t.html", "struct__xefg__swapchain__d3d12__resource__data__t" ],
    [ "_xefg_swapchain_frame_constant_data_t", "struct__xefg__swapchain__frame__constant__data__t.html", "struct__xefg__swapchain__frame__constant__data__t" ],
    [ "_xefg_swapchain_present_status_t", "struct__xefg__swapchain__present__status__t.html", "struct__xefg__swapchain__present__status__t" ],
    [ "_xefg_swapchain_properties_t", "struct__xefg__swapchain__properties__t.html", "struct__xefg__swapchain__properties__t" ],
    [ "_xefg_swapchain_version_t", "struct__xefg__swapchain__version__t.html", "struct__xefg__swapchain__version__t" ]
];