var searchData=
[
  ['jitteroffsetx_0',['jitterOffsetX',['../struct__xess__d3d11__execute__params__t.html#a701953ac726be26afde35ba21b1854f5',1,'_xess_d3d11_execute_params_t::jitterOffsetX()'],['../struct__xess__d3d12__execute__params__t.html#a701953ac726be26afde35ba21b1854f5',1,'_xess_d3d12_execute_params_t::jitterOffsetX()'],['../struct__xess__vk__execute__params__t.html#a701953ac726be26afde35ba21b1854f5',1,'_xess_vk_execute_params_t::jitterOffsetX()']]],
  ['jitteroffsety_1',['jitterOffsetY',['../struct__xess__d3d11__execute__params__t.html#ab8fec73568168bc8ba655190c20b98b0',1,'_xess_d3d11_execute_params_t::jitterOffsetY()'],['../struct__xess__d3d12__execute__params__t.html#ab8fec73568168bc8ba655190c20b98b0',1,'_xess_d3d12_execute_params_t::jitterOffsetY()'],['../struct__xess__vk__execute__params__t.html#ab8fec73568168bc8ba655190c20b98b0',1,'_xess_vk_execute_params_t::jitterOffsetY()']]]
];
