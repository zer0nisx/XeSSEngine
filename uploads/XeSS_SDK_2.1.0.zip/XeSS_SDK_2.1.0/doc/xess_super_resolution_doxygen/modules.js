var modules =
[
    [ "XeSS API exports", "group__xess.html", "group__xess" ],
    [ "XeSS D3D11 API exports", "group__xess-d3d11.html", "group__xess-d3d11" ],
    [ "XeSS D3D12 API exports", "group__xess-d3d12.html", "group__xess-d3d12" ],
    [ "XeSS D3D12 API debug exports", "group__xess-d3d12-debug.html", "group__xess-d3d12-debug" ],
    [ "XeSS API debug exports", "group__xess-debug.html", "group__xess-debug" ],
    [ "XeSS VK API exports", "group__xess-vulkan.html", "group__xess-vulkan" ],
    [ "XeSS Vulkan API debug exports", "group__xess-vk-debug.html", "group__xess-vk-debug" ]
];