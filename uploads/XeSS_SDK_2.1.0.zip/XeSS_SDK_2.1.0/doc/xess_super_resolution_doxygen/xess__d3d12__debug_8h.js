var xess__d3d12__debug_8h =
[
    [ "_xess_resources_to_dump_t", "struct__xess__resources__to__dump__t.html", "struct__xess__resources__to__dump__t" ],
    [ "XESS_D3D12_DEBUG_ENABLE_PROFILING", "xess__d3d12__debug_8h.html#ad587f5e54cc2f41c539dd8983e248cb2", null ],
    [ "xess_resources_to_dump_t", "xess__d3d12__debug_8h.html#a16c2ebf61da2c3a48f3c985c1fb9b8e7", null ],
    [ "xessD3D12GetProfilingData", "group__xess-d3d12-debug.html#ga3a8e8bee0b8ba06871c765648202c938", null ],
    [ "xessD3D12GetResourcesToDump", "group__xess-d3d12-debug.html#gaf62cb7b5e756de611a19896a5248c92b", null ]
];