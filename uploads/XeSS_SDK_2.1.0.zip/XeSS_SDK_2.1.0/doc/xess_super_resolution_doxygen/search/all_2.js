var searchData=
[
  ['border_5fpixels_5fto_5fskip_5fcount_0',['border_pixels_to_skip_count',['../struct__xess__resources__to__dump__t.html#a4b329d03d60ffb48e496e41169018a31',1,'_xess_resources_to_dump_t::border_pixels_to_skip_count()'],['../struct__xess__vk__resources__to__dump__t.html#a4b329d03d60ffb48e496e41169018a31',1,'_xess_vk_resources_to_dump_t::border_pixels_to_skip_count()']]],
  ['buffer_1',['buffer',['../struct__xess__vk__resource__to__dump__desc__t.html#afb1211892a082f365aec675b78078cc5',1,'_xess_vk_resource_to_dump_desc_t']]],
  ['bufferheapoffset_2',['bufferHeapOffset',['../struct__xess__d3d12__init__params__t.html#aca551e5731fdfe7679b6f3e24cc01d0c',1,'_xess_d3d12_init_params_t::bufferHeapOffset()'],['../struct__xess__vk__init__params__t.html#aca551e5731fdfe7679b6f3e24cc01d0c',1,'_xess_vk_init_params_t::bufferHeapOffset()']]]
];
