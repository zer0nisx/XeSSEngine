var searchData=
[
  ['incomingstate_0',['incomingState',['../struct__xefg__swapchain__d3d12__resource__data__t.html#af24abfcc57a728d25d91b7b75a13553d',1,'_xefg_swapchain_d3d12_resource_data_t']]],
  ['initflags_1',['initFlags',['../struct__xefg__swapchain__d3d12__init__params__t.html#a2778ccc4a0cacda6c2c73482a77f6e05',1,'_xefg_swapchain_d3d12_init_params_t']]],
  ['isframegenenabled_2',['isFrameGenEnabled',['../struct__xefg__swapchain__present__status__t.html#a61ea2b8bf9271fe0500464d4b37f82fe',1,'_xefg_swapchain_present_status_t']]]
];
