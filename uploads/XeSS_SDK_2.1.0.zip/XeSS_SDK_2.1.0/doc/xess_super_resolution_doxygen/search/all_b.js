var searchData=
[
  ['major_0',['major',['../struct__xess__version__t.html#a600930655b7237315b72223c48327ea8',1,'_xess_version_t']]],
  ['minor_1',['minor',['../struct__xess__version__t.html#a9f280ce3ae5b6cd9346fd7a09ff29168',1,'_xess_version_t']]]
];
