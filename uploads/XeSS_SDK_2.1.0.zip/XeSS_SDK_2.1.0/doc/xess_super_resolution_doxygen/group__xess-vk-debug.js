var group__xess_vk_debug =
[
    [ "xessVKGetResourcesToDump", "group__xess-vk-debug.html#gaa5464710fa5a818d07340f470b4d522c", null ]
];