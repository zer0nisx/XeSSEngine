var group__xefgswapchain__debug =
[
    [ "xefgSwapChainEnableDebugFeature", "group__xefgswapchain__debug.html#gaf2d5b3aa72a5615fd5ac700b5574c231", null ]
];