var struct__xess__resources__to__dump__t =
[
    [ "as_tensor", "struct__xess__resources__to__dump__t.html#a055a00bb33a3ade096f537cee6d614ca", null ],
    [ "border_pixels_to_skip_count", "struct__xess__resources__to__dump__t.html#a4b329d03d60ffb48e496e41169018a31", null ],
    [ "resource_count", "struct__xess__resources__to__dump__t.html#afa5d343e953478907a576e9c372a5838", null ],
    [ "resource_names", "struct__xess__resources__to__dump__t.html#a4f61a0f5b6b502a4cd89405410853fde", null ],
    [ "resources", "struct__xess__resources__to__dump__t.html#aeb3cb43b5376fe80794c4f5e4b47ff68", null ],
    [ "tensor_channel_count", "struct__xess__resources__to__dump__t.html#ae59e9714ae9a69c614783e31a585a221", null ],
    [ "tensor_height", "struct__xess__resources__to__dump__t.html#a7d6bf0ceee8b6abbb2678a630531e4fb", null ],
    [ "tensor_width", "struct__xess__resources__to__dump__t.html#a1b5c859fbf4a5eb748d5381e6063f673", null ]
];