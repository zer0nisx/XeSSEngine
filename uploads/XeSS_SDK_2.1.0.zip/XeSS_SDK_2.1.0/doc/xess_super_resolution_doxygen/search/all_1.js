var searchData=
[
  ['any_5fprofiling_5fdata_5fin_5fflight_0',['any_profiling_data_in_flight',['../struct__xess__profiling__data__t.html#a7ce6d3494f6a8695edf94fcad38c455e',1,'_xess_profiling_data_t']]],
  ['as_5ftensor_1',['as_tensor',['../struct__xess__resources__to__dump__t.html#a055a00bb33a3ade096f537cee6d614ca',1,'_xess_resources_to_dump_t::as_tensor()'],['../struct__xess__vk__resources__to__dump__t.html#a055a00bb33a3ade096f537cee6d614ca',1,'_xess_vk_resources_to_dump_t::as_tensor()']]]
];
