var searchData=
[
  ['constantbuffersize_0',['constantBufferSize',['../struct__xefg__swapchain__properties__t.html#af5ae06f4022007022b49a3cfaf2a9544',1,'_xefg_swapchain_properties_t']]],
  ['creationnodemask_1',['creationNodeMask',['../struct__xefg__swapchain__d3d12__init__params__t.html#a5a826e34a732802a584fc78091837dc4',1,'_xefg_swapchain_d3d12_init_params_t']]]
];
