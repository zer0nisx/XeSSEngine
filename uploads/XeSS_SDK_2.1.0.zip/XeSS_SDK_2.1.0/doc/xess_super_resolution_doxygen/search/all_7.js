var searchData=
[
  ['gpu_5fduration_5fnames_0',['gpu_duration_names',['../struct__xess__profiled__frame__data__t.html#a46e787a4e8a96da32fe2b173f3720d6f',1,'_xess_profiled_frame_data_t']]],
  ['gpu_5fduration_5frecord_5fcount_1',['gpu_duration_record_count',['../struct__xess__profiled__frame__data__t.html#ab142b6f60de7c00c227011353cb602e5',1,'_xess_profiled_frame_data_t']]],
  ['gpu_5fduration_5fvalues_2',['gpu_duration_values',['../struct__xess__profiled__frame__data__t.html#a8f6650843400b1532bdd0ce000a0e689',1,'_xess_profiled_frame_data_t']]]
];
