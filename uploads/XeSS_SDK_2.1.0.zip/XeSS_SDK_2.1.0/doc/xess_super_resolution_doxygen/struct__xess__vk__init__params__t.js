var struct__xess__vk__init__params__t =
[
    [ "bufferHeapOffset", "struct__xess__vk__init__params__t.html#aca551e5731fdfe7679b6f3e24cc01d0c", null ],
    [ "creationNodeMask", "struct__xess__vk__init__params__t.html#a5a826e34a732802a584fc78091837dc4", null ],
    [ "initFlags", "struct__xess__vk__init__params__t.html#a2778ccc4a0cacda6c2c73482a77f6e05", null ],
    [ "outputResolution", "struct__xess__vk__init__params__t.html#adefd841ee2588585d89bf91ced85e84c", null ],
    [ "pipelineCache", "struct__xess__vk__init__params__t.html#af41e2c502fc1ad3d4039dee45ca26b18", null ],
    [ "qualitySetting", "struct__xess__vk__init__params__t.html#ad1566e156f30842fc8a32e5e508094b2", null ],
    [ "tempBufferHeap", "struct__xess__vk__init__params__t.html#a7a786f1ecfcf7c3f2825b9ea257c0ff0", null ],
    [ "tempTextureHeap", "struct__xess__vk__init__params__t.html#a2760d04db8e256c1d31ea1afda46ee7e", null ],
    [ "textureHeapOffset", "struct__xess__vk__init__params__t.html#a9e2ba8ca5471d07e4bb30183deb00e56", null ],
    [ "visibleNodeMask", "struct__xess__vk__init__params__t.html#a153b79c833ddce15c33d78691a679ca3", null ]
];