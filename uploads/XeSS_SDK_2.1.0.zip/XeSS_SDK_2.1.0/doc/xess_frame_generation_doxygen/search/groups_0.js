var searchData=
[
  ['xess_2dfg_20swap_20chain_20api_20exports_0',['XeSS-FG Swap Chain API exports',['../group__xefgswapchain.html',1,'']]],
  ['xess_2dfg_20swap_20chain_20d3d12_20api_20exports_1',['XeSS-FG Swap Chain D3D12 API exports',['../group__xefgswapchain-d3d12.html',1,'']]],
  ['xess_2dfg_20swap_20chain_20debug_20features_2',['XeSS-FG Swap Chain debug features',['../group__xefgswapchain__debug.html',1,'']]]
];
