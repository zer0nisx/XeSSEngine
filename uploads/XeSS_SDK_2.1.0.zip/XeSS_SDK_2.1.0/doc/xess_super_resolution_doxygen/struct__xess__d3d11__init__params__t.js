var struct__xess__d3d11__init__params__t =
[
    [ "initFlags", "struct__xess__d3d11__init__params__t.html#a2778ccc4a0cacda6c2c73482a77f6e05", null ],
    [ "outputResolution", "struct__xess__d3d11__init__params__t.html#adefd841ee2588585d89bf91ced85e84c", null ],
    [ "qualitySetting", "struct__xess__d3d11__init__params__t.html#ad1566e156f30842fc8a32e5e508094b2", null ]
];