var searchData=
[
  ['tempbufferheapsize_0',['tempBufferHeapSize',['../struct__xefg__swapchain__properties__t.html#a0db8617705e860098e048d7f3e5466ff',1,'_xefg_swapchain_properties_t']]],
  ['temptextureheapsize_1',['tempTextureHeapSize',['../struct__xefg__swapchain__properties__t.html#a209e8c58699154a12ca8c51d190565ee',1,'_xefg_swapchain_properties_t']]],
  ['textureheapoffset_2',['textureHeapOffset',['../struct__xefg__swapchain__d3d12__init__params__t.html#a9e2ba8ca5471d07e4bb30183deb00e56',1,'_xefg_swapchain_d3d12_init_params_t']]],
  ['type_3',['type',['../struct__xefg__swapchain__d3d12__resource__data__t.html#acb5d94c09d77cd739ad2a31cb9931443',1,'_xefg_swapchain_d3d12_resource_data_t']]]
];
