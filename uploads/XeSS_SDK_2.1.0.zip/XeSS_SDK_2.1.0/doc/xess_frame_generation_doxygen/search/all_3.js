var searchData=
[
  ['framegenresult_0',['frameGenResult',['../struct__xefg__swapchain__present__status__t.html#a61d64decd8963c48a3bdc1d0e3051479',1,'_xefg_swapchain_present_status_t']]],
  ['framerendertime_1',['frameRenderTime',['../struct__xefg__swapchain__frame__constant__data__t.html#a177cfa7f26fd6469195fb08f59579218',1,'_xefg_swapchain_frame_constant_data_t']]],
  ['framespresented_2',['framesPresented',['../struct__xefg__swapchain__present__status__t.html#a2fe0993bf79740d78bbbb3c9f093c2d0',1,'_xefg_swapchain_present_status_t']]]
];
