var searchData=
[
  ['xefg_5fswapchain_5fapi_0',['XEFG_SWAPCHAIN_API',['../xefg__swapchain_8h.html#a44f6366bc2b38f7ff85fc2f4afa54fee',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fcat_1',['XEFG_SWAPCHAIN_CAT',['../xefg__swapchain_8h.html#a573260e9493e3e9a6f421defb418df17',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fcat_5fimpl_2',['XEFG_SWAPCHAIN_CAT_IMPL',['../xefg__swapchain_8h.html#a92f06315267d90738bae30d819e91172',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fpack_5fb_3',['XEFG_SWAPCHAIN_PACK_B',['../xefg__swapchain_8h.html#a724c50dc5c0f3222fc55c7adc7acaa52',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fpack_5fb_5fx_4',['XEFG_SWAPCHAIN_PACK_B_X',['../xefg__swapchain_8h.html#a4b0de771302c8e6174f942b9993bd9ce',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fpack_5fe_5',['XEFG_SWAPCHAIN_PACK_E',['../xefg__swapchain_8h.html#a333c83bf005356bed6724c5f5b51d7d6',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fpragma_6',['XEFG_SWAPCHAIN_PRAGMA',['../xefg__swapchain_8h.html#a441be7eb9434e15555d72275f1f09a76',1,'xefg_swapchain.h']]],
  ['xefg_5fswapchain_5fstatic_5fassert_7',['XEFG_SWAPCHAIN_STATIC_ASSERT',['../xefg__swapchain_8h.html#aa4f6797e657a445fe2335f9ed143074f',1,'xefg_swapchain.h']]]
];
