var group__xefgswapchain =
[
    [ "xefgSwapChainDestroy", "group__xefgswapchain.html#ga1dc325c074ef6ca284dad9e6d864687b", null ],
    [ "xefgSwapChainGetLastPresentStatus", "group__xefgswapchain.html#ga0ecf1f246a2817d95a56fbdaed03a1bf", null ],
    [ "xefgSwapChainGetPipelineBuildStatus", "group__xefgswapchain.html#ga3f119c078bd1df0033df4f53bfd8f88c", null ],
    [ "xefgSwapChainGetProperties", "group__xefgswapchain.html#gadc3d638ba3f1cdfab037017e171ac533", null ],
    [ "xefgSwapChainGetVersion", "group__xefgswapchain.html#gae5814f06f251c21cf8e6d27ee073e44d", null ],
    [ "xefgSwapChainSetEnabled", "group__xefgswapchain.html#ga0736dcd0aa28b66ae84f47d1eeee8cf8", null ],
    [ "xefgSwapChainSetLatencyReduction", "group__xefgswapchain.html#ga78d583d6998d2ce952edff7d0ec2f283", null ],
    [ "xefgSwapChainSetLoggingCallback", "group__xefgswapchain.html#ga7c95b36660495ccfdb84dd95bd2f40ac", null ],
    [ "xefgSwapChainSetPresentId", "group__xefgswapchain.html#ga99d3ede193b7f015c37e58475121585e", null ],
    [ "xefgSwapChainSetSceneChangeThreshold", "group__xefgswapchain.html#ga7ac3e8f95efa59a95607c0c6d248e824", null ],
    [ "xefgSwapChainTagFrameConstants", "group__xefgswapchain.html#gac881c68bad8488c3e4e916cdd011b336", null ]
];