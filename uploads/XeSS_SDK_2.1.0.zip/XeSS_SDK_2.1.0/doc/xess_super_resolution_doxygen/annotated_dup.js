var annotated_dup =
[
    [ "_xess_2d_t", "struct__xess__2d__t.html", "struct__xess__2d__t" ],
    [ "_xess_d3d11_execute_params_t", "struct__xess__d3d11__execute__params__t.html", "struct__xess__d3d11__execute__params__t" ],
    [ "_xess_d3d11_init_params_t", "struct__xess__d3d11__init__params__t.html", "struct__xess__d3d11__init__params__t" ],
    [ "_xess_d3d12_execute_params_t", "struct__xess__d3d12__execute__params__t.html", "struct__xess__d3d12__execute__params__t" ],
    [ "_xess_d3d12_init_params_t", "struct__xess__d3d12__init__params__t.html", "struct__xess__d3d12__init__params__t" ],
    [ "_xess_dump_parameters_t", "struct__xess__dump__parameters__t.html", "struct__xess__dump__parameters__t" ],
    [ "_xess_profiled_frame_data_t", "struct__xess__profiled__frame__data__t.html", "struct__xess__profiled__frame__data__t" ],
    [ "_xess_profiling_data_t", "struct__xess__profiling__data__t.html", "struct__xess__profiling__data__t" ],
    [ "_xess_properties_t", "struct__xess__properties__t.html", "struct__xess__properties__t" ],
    [ "_xess_resources_to_dump_t", "struct__xess__resources__to__dump__t.html", "struct__xess__resources__to__dump__t" ],
    [ "_xess_version_t", "struct__xess__version__t.html", "struct__xess__version__t" ],
    [ "_xess_vk_execute_params_t", "struct__xess__vk__execute__params__t.html", "struct__xess__vk__execute__params__t" ],
    [ "_xess_vk_image_view_info", "struct__xess__vk__image__view__info.html", "struct__xess__vk__image__view__info" ],
    [ "_xess_vk_init_params_t", "struct__xess__vk__init__params__t.html", "struct__xess__vk__init__params__t" ],
    [ "_xess_vk_resource_to_dump_desc_t", "struct__xess__vk__resource__to__dump__desc__t.html", "struct__xess__vk__resource__to__dump__desc__t" ],
    [ "_xess_vk_resources_to_dump_t", "struct__xess__vk__resources__to__dump__t.html", "struct__xess__vk__resources__to__dump__t" ]
];